#include "abr.h"
#include <iostream>

using namespace std;
node::node(int k) {
	key=k;
	fg=fd=pere=NULL;
}

void node::print() {
	if(fg) fg->print();
	cout<<key<<" ";
	if(fd) fd->print();
}

void node::add(int k) {
	if(k<key) {
		if (fg) fg->add(k);
		else {
			fg=new node(k);
			fg->pere=this;
		}
	} else {
		if(fd) fd->add(k);
		else {
			fd=new node(k);
			fd->pere=this;
		}
	}
}

bool node::search(int k) {
	if(k==key) return true;
	if(k<key) {
		if(fg) return(fg->search(k));
		else {
			return false;
		}
	} else {
		if(fd) return(fd->search(k));
		else {
			return false;
		}
	}
}

node * node::min() {
	if(fg) return fg->min();
	else return this;
}

node * node::max() {
	if(fd) return fd->max();
	else return this;
}

int node::get() {
	return key;
}

node * arbre::min() {
	if(r) return r->min();
	else return NULL;
}

node * arbre::max() {
	if(r) return r->max();
	else return NULL;
}

void arbre::print() {
	if(r) r->print();
	else cout<<"Empty."<<endl;
}


arbre::arbre() {
	r=NULL;
}

bool arbre::search(int k) {
	if(r) return r->search(k);
	else return false;
}

void arbre::add(int k) {
	if(r) r->add(k);
	else {
		r=new node(k);
	}
}

int main() {
	int k;
	arbre A;
	k=4;
	A.add(k);
	k=6;
	A.add(k);
	k=2;
	A.add(k);
	cout << A.search(k) << endl;
	cout << A.min()->get() << endl;
	cout << A.max()->get() << endl;
}
