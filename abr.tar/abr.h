class node {
	int key;
	node *fg;
	node *fd;
	node *pere;
	public:
		node(int k);
		void add(int k);
		void print();
		bool search(int n);
		node * min();
		node * max();
		int get();		
};
class arbre {
	node * r;

	public:
		arbre();
		void add(int c);
		void print();
		bool search(int k);
		node * max();
		node * min();
};
